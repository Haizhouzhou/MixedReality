// <copyright file="OpenXRAndroidApi.cs" company="Google LLC">
//
// Copyright 2024 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// </copyright>
//-----------------------------------------------------------------------

namespace Google.XR.Extensions.Internal
{
    using System;
    using System.Runtime.InteropServices;
    using UnityEngine;
    using UnityEngine.XR.OpenXR.NativeTypes;

    internal class OpenXRAndroidApi
    {
        public static bool TryGetRecommendedSettings(ref XrRecommendedSettings recommendedSettings)
        {
            return ExternalApi.OpenXRAndroid_getRecommendedSettings(
                XRInstanceManagerApi.GetIntPtr(), ref recommendedSettings);
        }

        private struct ExternalApi
        {
            [DllImport(ApiConstants.OpenXRAndroidApi)]
            public static extern bool OpenXRAndroid_getRecommendedSettings(
                IntPtr manager, ref XrRecommendedSettings recommendedSettings);
        }
    }
}
